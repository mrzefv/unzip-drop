//
//  RootView.swift
//  mSignLite
//
//  The shell: a fixed top bar and a five-tab bottom bar, matching the
//  full mSign layout — Files · Browse · Library · Signed · Settings.
//

import SwiftUI

struct RootView: View {
    @State private var tab = 2   // open on Library

    init() {
        let a = UITabBarAppearance()
        a.configureWithOpaqueBackground()
        a.backgroundColor = UIColor(Theme.bg)
        UITabBar.appearance().standardAppearance = a
        UITabBar.appearance().scrollEdgeAppearance = a
    }

    var body: some View {
        VStack(spacing: 0) {
            TopBar()
            TabView(selection: $tab) {
                FilesView()
                    .tabItem { Label("Files", systemImage: "folder.fill") }.tag(0)
                BrowseView()
                    .tabItem { Label("Browse", systemImage: "safari.fill") }.tag(1)
                LibraryView()
                    .tabItem { Label("Library", systemImage: "square.grid.2x2.fill") }.tag(2)
                SignedView()
                    .tabItem { Label("Signed", systemImage: "checkmark.seal.fill") }.tag(3)
                SettingsView()
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }.tag(4)
            }
            .tint(Theme.accent)
        }
        .background(Theme.bg.ignoresSafeArea())
        .preferredColorScheme(.dark)
    }
}
