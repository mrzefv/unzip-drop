//
//  SettingsView.swift
//  mSignLite
//

import SwiftUI

struct SettingsView: View {
    @ObservedObject private var certs = CertificateStore.shared
    @State private var host = ServerConfig.installHost
    @State private var home = BrowseConfig.home

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.bg.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 14) {
                        HStack { Text("Settings").font(.title2.bold()).foregroundStyle(Theme.text); Spacer() }

                        NavigationLink {
                            CertificatesView()
                                .toolbarBackground(Theme.bg, for: .navigationBar)
                                .toolbarBackground(.visible, for: .navigationBar)
                        } label: {
                            Card {
                                HStack(spacing: 12) {
                                    Image(systemName: "checkmark.shield.fill").foregroundStyle(Theme.accent)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Certificates").font(.headline).foregroundStyle(Theme.text)
                                        Text(certs.active?.name ?? "No signing certificate")
                                            .font(.caption).foregroundStyle(certs.active == nil ? .orange : Theme.subtle)
                                    }
                                    Spacer()
                                    Text("\(certs.certificates.count)").font(.caption).foregroundStyle(Theme.subtle)
                                    Image(systemName: "chevron.right").font(.caption).foregroundStyle(Theme.subtle)
                                }
                            }
                        }
                        .buttonStyle(.plain)

                        Card {
                            VStack(alignment: .leading, spacing: 8) {
                                Label("Install domain", systemImage: "network")
                                    .font(.headline).foregroundStyle(Theme.text)
                                Text("The OTA host. Must resolve to 127.0.0.1 and be covered by the bundled cert (Resources/server.*). Default *.zefv.dev.")
                                    .font(.caption).foregroundStyle(Theme.subtle)
                                field($host, placeholder: "mr.zefv.dev") { ServerConfig.setInstallHost($0) }
                            }
                        }

                        Card {
                            VStack(alignment: .leading, spacing: 8) {
                                Label("Browser home", systemImage: "safari")
                                    .font(.headline).foregroundStyle(Theme.text)
                                Text("Where the Browse tab opens. IPA links downloaded there drop into Library.")
                                    .font(.caption).foregroundStyle(Theme.subtle)
                                field($home, placeholder: "https://mrzefv.com") { BrowseConfig.setHome($0) }
                            }
                        }

                        Card {
                            VStack(alignment: .leading, spacing: 8) {
                                Label("How it works", systemImage: "info.circle")
                                    .font(.headline).foregroundStyle(Theme.text)
                                bullet("Import an unsigned .ipa in Library, or grab one in Browse.")
                                bullet("Add an Apple certificate (.p12 + .mobileprovision) in Settings › Certificates.")
                                bullet("Sign on-device with zsign, then install over the built-in HTTPS server.")
                                bullet("No backend — signing and OTA all happen on this device.")
                            }
                        }

                        Card {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(Theme.appName).font(.headline).foregroundStyle(Theme.text)
                                    Text("Version \(Theme.appVersion)").font(.caption).foregroundStyle(Theme.subtle)
                                }
                                Spacer()
                                Image(systemName: "signature").foregroundStyle(Theme.accent)
                            }
                        }

                        Text(Theme.owner).font(.footnote).foregroundStyle(Theme.subtle)
                            .frame(maxWidth: .infinity)
                    }
                    .padding(16)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private func field(_ text: Binding<String>, placeholder: String, onChange: @escaping (String) -> Void) -> some View {
        TextField(placeholder, text: text)
            .autocorrectionDisabled().textInputAutocapitalization(.never)
            .padding(10).background(Theme.bg).foregroundStyle(Theme.text)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .onChange(of: text.wrappedValue) { newValue in onChange(newValue) }
    }

    private func bullet(_ s: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Circle().fill(Theme.accent).frame(width: 5, height: 5).padding(.top, 6)
            Text(s).font(.caption).foregroundStyle(Theme.subtle)
        }
    }
}
