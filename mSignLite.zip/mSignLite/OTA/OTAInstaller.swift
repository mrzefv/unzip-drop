//
//  OTAInstaller.swift
//  mSignLite
//
//  Serves a locally-signed IPA over LocalOTAServer and hands iOS the
//  itms-services URL. Keeps the server alive under a background task for
//  the ~90s installd needs to pull the manifest + payload.
//

import Foundation
import UIKit

@MainActor
final class OTAInstaller {
    static let shared = OTAInstaller()
    private init() {}

    private var current: LocalOTAServer?
    private var bgTask: UIBackgroundTaskIdentifier = .invalid

    enum InstallError: LocalizedError {
        case ipaMissing
        var errorDescription: String? { "Signed IPA not found on disk." }
    }

    func install(_ app: SignedEntry) async throws {
        let icon = app.iconURL.flatMap { try? Data(contentsOf: $0) }
        try await install(ipaURL: app.ipaURL, bundleID: app.bundleID,
                          name: app.name, version: app.version, iconData: icon)
    }

    func install(ipaURL: URL, bundleID: String, name: String, version: String,
                 iconData: Data?) async throws {
        guard FileManager.default.fileExists(atPath: ipaURL.path) else { throw InstallError.ipaMissing }

        let icon57  = Self.squarePNG(iconData, side: 57)
        let icon512 = Self.squarePNG(iconData, side: 512)

        tearDown()
        let server = try LocalOTAServer(ipaURL: ipaURL, bundleID: bundleID, name: name,
                                        version: version, icon57: icon57, icon512: icon512)
        server.start()
        current = server

        // Keep serving while backgrounded during the install.
        bgTask = UIApplication.shared.beginBackgroundTask(withName: "ota-install") { [weak self] in
            self?.tearDown()
        }

        UIApplication.shared.open(server.itmsURL)

        Task { [weak self] in
            try? await Task.sleep(nanoseconds: 90 * 1_000_000_000)
            self?.tearDown()
        }
    }

    private func tearDown() {
        current?.stop(); current = nil
        if bgTask != .invalid { UIApplication.shared.endBackgroundTask(bgTask); bgTask = .invalid }
    }

    /// Draw the app icon into a solid square PNG (aspect-fill), or a flat
    /// tile if no icon is available. installd only needs valid PNGs.
    private static func squarePNG(_ data: Data?, side: CGFloat) -> Data {
        let size = CGSize(width: side, height: side)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            UIColor(red: 0.06, green: 0.06, blue: 0.06, alpha: 1).setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            if let data, let img = UIImage(data: data) {
                img.draw(in: CGRect(origin: .zero, size: size))
            }
        }.pngData() ?? Data()
    }
}
