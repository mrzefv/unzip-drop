//
//  mSignLite-Bridging-Header.h
//  mSignLite
//
//  Exposes the zsign C/ObjC++ signing pipeline to Swift.
//  zsign.hpp declares its entrypoints inside `extern "C"`, so they import
//  into Swift as free functions: zsign(...), InjectDyLib(...),
//  ChangeDylibPath(...), ListDylibs(...), UninstallDylibs(...),
//  ZSignSetParallel(...).
//

#ifndef mSignLite_Bridging_Header_h
#define mSignLite_Bridging_Header_h

#import "Services/zsign/zsign.hpp"

#endif /* mSignLite_Bridging_Header_h */
