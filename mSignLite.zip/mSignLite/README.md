# mSign Lite

A lightweight, self-contained on-device iOS **IPA signer**. Import an unsigned
`.ipa`, sign it on-device with the **zsign** engine using your own Apple
certificate, and install it over a **built-in HTTPS OTA server** — no backend,
no computer, no TrollStore.

Built to compile **unsigned on GitHub Actions**, so you can iterate entirely
from GitHub and sign the result on-device.

> Attribution: **MRzefv** · mrzefv.com

---

## What's in it

Just the essentials — a fixed top bar and five bottom tabs:

- **Files** — browse the app sandbox, import/share/delete files, make folders.
- **Browse** — in-app browser (defaults to mrzefv.com); `.ipa` links download straight into Library.
- **Library** — import unsigned `.ipa`s, tap to sign.
- **Signed** — install signed apps over the air.
- **Settings** — install domain, browser home, and **Certificates** (import `.p12` + `.mobileprovision`, pick the active one).
- **Settings** — set the OTA install domain.

Everything heavier from the full app (disassembler, tweak pipelines, parallel
DAG signing, forum/account/backend, TrollStore helpers, multi-identity/ACME)
is intentionally **left out**. Add what you need on top.

### Dependencies (only two)

- [ZIPFoundation](https://github.com/weichsel/ZIPFoundation) — IPA pack/unpack
- [OpenSSL-Swift-Package](https://github.com/HAHALOSAH/OpenSSL-Swift-Package) — required by zsign

No Vapor, no SwiftNIO. The OTA server is a tiny `NWListener` HTTPS server
(`OTA/LocalOTAServer.swift`) built on Apple's Network framework.

---

## Build on GitHub (no Mac needed)

1. Push this repo to GitHub.
2. **Actions → Build mSign Lite (unsigned IPA) → Run workflow.**
3. Download the `mSignLite-unsigned-ipa` artifact.
4. Sign it on-device (with mSign Lite itself, or any signer) and install.

The workflow (`.github/workflows/build.yml`) runs on `macos-15` and builds
with code signing disabled.

---

## The self-hosted OTA trick

`itms-services` OTA installs require HTTPS with a **publicly-trusted** cert.
The bundled cert (`Resources/server.crt` / `server.pem` / `server.p12`) is a
real Let's Encrypt wildcard for `*.zefv.dev`, and `*.zefv.dev` resolves to
`127.0.0.1`. So:

1. The app runs a small HTTPS server on-device (loopback) using that cert.
2. It serves an `itms-services` manifest + the signed IPA.
3. It opens `itms-services://…https://mr.zefv.dev:<port>/…`.
4. iOS trusts the cert, connects to localhost, installs. **Nothing leaves the
   device.**

### Use your own domain

- Get a wildcard cert (e.g. Let's Encrypt DNS-01) for a domain whose wildcard
  A record points at `127.0.0.1`.
- Replace `Resources/server.crt` + `server.pem`, and regenerate the p12:
  ```
  openssl pkcs12 -export -legacy -inkey server.pem -in server.crt \
    -out Resources/server.p12 -passout pass:
  ```
- Set the host in **Settings → Install domain** (default `mr.zefv.dev`).

The p12 is loaded at runtime via `SecPKCS12Import` and handed to `NWListener`
as the TLS identity.

---

## Layout

```
App/        @main, root tab shell, theme
Views/      the four screens + sign sheet
Stores/     Library / Signed / Certificate stores (JSON in Documents) + Keychain
Signing/    ZsignSigner (zsign wrapper), Signer pipeline, IPA metadata, log capture
OTA/        NWListener HTTPS server + installer
Services/   zsign C++ engine (verbatim)
Resources/  bundled TLS cert/key/p12
```

Folders are Xcode **file-system-synchronized groups** (objectVersion 77): drop
a `.swift` file into any of them and it's compiled automatically — no
`.pbxproj` edits.
