//
//  Models.swift
//  mSignLite
//
//  Plain Codable records. No CoreData — the lightweight build persists
//  everything as small JSON index files in Documents (see Stores/).
//

import Foundation

/// An imported, unsigned .ipa sitting in the local library.
struct LocalAppEntry: Codable, Identifiable, Equatable, Sendable {
    let id: String
    var name: String
    var bundleID: String
    var version: String
    /// Relative path under Documents (e.g. "library/<id>.ipa").
    var ipaRelPath: String
    /// Relative path under Documents to a cached icon PNG, if any.
    var iconRelPath: String?
    var importedAt: Date

    var ipaURL: URL { AppPaths.documents.appendingPathComponent(ipaRelPath) }
    var iconURL: URL? { iconRelPath.map { AppPaths.documents.appendingPathComponent($0) } }
}

/// A signed .ipa produced on-device, ready to install over the air.
struct SignedEntry: Codable, Identifiable, Equatable, Sendable {
    let id: String
    var name: String
    var bundleID: String
    var version: String
    var ipaRelPath: String
    var iconRelPath: String?
    var signedAt: Date

    var ipaURL: URL { AppPaths.documents.appendingPathComponent(ipaRelPath) }
    var iconURL: URL? { iconRelPath.map { AppPaths.documents.appendingPathComponent($0) } }
}

/// An imported signing certificate (.p12 + .mobileprovision).
/// The password lives in the Keychain, never in this record.
struct Certificate: Codable, Identifiable, Equatable, Sendable {
    let id: String
    var name: String
    var p12RelPath: String
    var provisionRelPath: String
    var addedAt: Date

    var p12URL: URL { AppPaths.documents.appendingPathComponent(p12RelPath) }
    var provisionURL: URL { AppPaths.documents.appendingPathComponent(provisionRelPath) }
}

/// Cert material handed to the signer (all in-memory value types).
struct CertMaterial: Sendable {
    let p12: Data
    let provision: Data
    let password: String
    let name: String
}

// MARK: - Shared filesystem locations

enum AppPaths {
    static var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    static func dir(_ name: String) -> URL {
        let u = documents.appendingPathComponent(name, isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }
}
