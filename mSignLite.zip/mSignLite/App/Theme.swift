//
//  Theme.swift
//  mSignLite
//

import SwiftUI

enum Theme {
    static let bg        = Color(red: 0.04, green: 0.05, blue: 0.06)
    static let card      = Color(red: 0.09, green: 0.11, blue: 0.12)
    static let stroke    = Color.white.opacity(0.06)
    static let accent    = Color(red: 0.18, green: 0.85, blue: 0.76)   // teal
    static let text      = Color(red: 0.92, green: 0.95, blue: 0.95)
    static let subtle    = Color(red: 0.55, green: 0.60, blue: 0.62)

    static let appName    = "mSIGN LITE"
    static let appVersion = "1.0"
    static let owner      = "mrzefv.com · MRzefv"
}

struct Card<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.card)
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Theme.stroke, lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}
