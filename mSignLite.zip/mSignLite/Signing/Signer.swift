//
//  Signer.swift
//  mSignLite
//
//  The whole on-device signing path, trimmed to essentials:
//  stage cert → unzip → zsign (with optional id/name/version overrides)
//  → repack (stored, no compression — it's served locally so deflate only
//  slows the install). Heavy extras (binary patching, tweak pipelines,
//  parallel DAG) are intentionally left out of the lightweight base.
//

import Foundation
import ZIPFoundation

struct SignOutcome: Sendable {
    let ipaURL: URL          // file:// temp path of the signed IPA
    let name: String
    let bundleID: String
    let version: String
}

enum Signer {

    nonisolated static func signDetached(
        ipaURL: URL,
        material: CertMaterial,
        nameOverride: String?,
        bundleIDOverride: String?,
        versionOverride: String?,
        onLog: (@Sendable (String) -> Void)? = nil
    ) async throws -> SignOutcome {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("sign-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        // 1. Stage cert + profile — zsign takes file paths.
        let p12URL  = work.appendingPathComponent("cert.p12")
        let provURL = work.appendingPathComponent("profile.mobileprovision")
        try material.p12.write(to: p12URL)
        try material.provision.write(to: provURL)

        // 2. Unzip → locate Payload/*.app
        let extractDir = work.appendingPathComponent("x", isDirectory: true)
        try fm.createDirectory(at: extractDir, withIntermediateDirectories: true)
        onLog?(">>> Extracting IPA…")
        try fm.unzipItem(at: ipaURL, to: extractDir)
        let payload = extractDir.appendingPathComponent("Payload", isDirectory: true)
        guard let appURL = try fm.contentsOfDirectory(at: payload, includingPropertiesForKeys: nil)
            .first(where: { $0.pathExtension == "app" }) else {
            throw ZsignError.appBundleNotFound(inIPA: ipaURL.lastPathComponent)
        }

        // 3. Sign in place — capture the engine's real stdout.
        let capture = onLog.map { ConsoleCapture($0) }
        capture?.start()
        do {
            try ZsignSigner.signAppBundle(
                appBundlePath: appURL.path,
                provisionPath: provURL.path,
                p12Path:       p12URL.path,
                p12Password:   material.password,
                bundleID:      bundleIDOverride,
                displayName:   nameOverride,
                version:       versionOverride
            )
            capture?.stop()
        } catch {
            capture?.stop()
            throw error
        }

        // 4. Read identifiers back from the (possibly overridden) Info.plist.
        let info = NSDictionary(contentsOf: appURL.appendingPathComponent("Info.plist"))
        let name = (info?["CFBundleDisplayName"] as? String)
            ?? (info?["CFBundleName"] as? String)
            ?? nameOverride ?? appURL.deletingPathExtension().lastPathComponent
        let bundleID = (info?["CFBundleIdentifier"] as? String) ?? bundleIDOverride ?? "unknown.bundle.id"
        let version  = (info?["CFBundleShortVersionString"] as? String) ?? versionOverride ?? "1.0"

        // 5. Repack (stored) → signed .ipa in temp.
        let signed = fm.temporaryDirectory
            .appendingPathComponent("\(name)-signed-\(UUID().uuidString)")
            .appendingPathExtension("ipa")
        try? fm.removeItem(at: signed)
        onLog?(">>> Packaging signed IPA…")
        try fm.zipItem(at: payload, to: signed, shouldKeepParent: true, compressionMethod: .none)
        onLog?(">>> Done.")

        return SignOutcome(ipaURL: signed, name: name, bundleID: bundleID, version: version)
    }
}
