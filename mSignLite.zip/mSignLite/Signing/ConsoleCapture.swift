//
//  ConsoleCapture.swift
//  mSignLite
//
//  zsign logs its real progress to stdout/stderr (SignFolder/SignFile,
//  timings). This taps those fds during a signing run so the UI can show
//  the actual engine log instead of a synthetic summary. Keep the capture
//  window tight around the C calls.
//

import Foundation
import Darwin

final class ConsoleCapture: @unchecked Sendable {
    private let onLine: @Sendable (String) -> Void
    private let pipe = Pipe()
    private var savedOut: Int32 = -1
    private var savedErr: Int32 = -1
    private var buffer = Data()
    private let lock = NSLock()

    init(_ onLine: @escaping @Sendable (String) -> Void) { self.onLine = onLine }

    func start() {
        savedOut = dup(fileno(stdout))
        savedErr = dup(fileno(stderr))
        setvbuf(stdout, nil, _IONBF, 0)
        dup2(pipe.fileHandleForWriting.fileDescriptor, fileno(stdout))
        dup2(pipe.fileHandleForWriting.fileDescriptor, fileno(stderr))

        pipe.fileHandleForReading.readabilityHandler = { [weak self] h in
            let d = h.availableData
            guard !d.isEmpty, let self else { return }
            self.lock.lock(); self.buffer.append(d); self.drain(); self.lock.unlock()
        }
    }

    func stop() {
        fflush(stdout); fflush(stderr)
        if savedOut >= 0 { dup2(savedOut, fileno(stdout)); close(savedOut); savedOut = -1 }
        if savedErr >= 0 { dup2(savedErr, fileno(stderr)); close(savedErr); savedErr = -1 }
        pipe.fileHandleForReading.readabilityHandler = nil
        lock.lock()
        if !buffer.isEmpty { emit(String(decoding: buffer, as: UTF8.self)); buffer.removeAll() }
        lock.unlock()
    }

    private func drain() {
        while let nl = buffer.firstIndex(of: 0x0A) {
            let line = buffer.subdata(in: buffer.startIndex..<nl)
            buffer.removeSubrange(buffer.startIndex...nl)
            emit(String(decoding: line, as: UTF8.self))
        }
    }

    private func emit(_ text: String) {
        let t = text.trimmingCharacters(in: .newlines)
        guard !t.isEmpty else { return }
        onLine(t)
    }
}
