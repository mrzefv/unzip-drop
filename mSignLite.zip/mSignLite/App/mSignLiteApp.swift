//
//  mSignLiteApp.swift
//  mSignLite
//
//  A lightweight on-device IPA signer: import → sign (zsign) → install
//  over a self-hosted HTTPS OTA server. Build unsigned on GitHub, then
//  sign it on-device with any Apple certificate.
//
//  Attribution: MRzefv · mrzefv.com
//

import SwiftUI

@main
struct mSignLiteApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
