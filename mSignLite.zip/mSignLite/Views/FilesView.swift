//
//  FilesView.swift
//  mSignLite
//
//  A real file browser over the app's sandbox (Documents). Walk folders,
//  see sizes, share or delete, import arbitrary files, make folders.
//  This is where library/, signed/ and certs/ actually live on disk.
//

import SwiftUI
import UniformTypeIdentifiers

private struct FileItem: Identifiable {
    let url: URL
    let isDir: Bool
    let size: Int64
    let modified: Date
    var id: String { url.path }
    var name: String { url.lastPathComponent }
}

struct FilesView: View {
    @State private var dir: URL = AppPaths.documents
    @State private var items: [FileItem] = []

    @State private var importing = false
    @State private var newFolder = false
    @State private var folderName = ""
    @State private var shareURL: URL?
    @State private var error: String?

    private var atRoot: Bool { dir.standardizedFileURL == AppPaths.documents.standardizedFileURL }
    private var relPath: String {
        let base = AppPaths.documents.standardizedFileURL.path
        let here = dir.standardizedFileURL.path
        let r = here.hasPrefix(base) ? String(here.dropFirst(base.count)) : here
        return r.isEmpty ? "/" : r
    }

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                if items.isEmpty {
                    empty
                } else {
                    List {
                        ForEach(items) { item in row(item) }
                            .listRowBackground(Theme.card)
                            .listRowSeparatorTint(Theme.stroke)
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                }
            }
        }
        .onAppear(perform: reload)
        .fileImporter(isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true) { res in
            if case let .success(urls) = res { importFiles(urls) }
        }
        .sheet(item: shareItem) { s in ShareSheet(items: [s.url]) }
        .alert("New folder", isPresented: $newFolder) {
            TextField("name", text: $folderName)
            Button("Create") { makeFolder() }
            Button("Cancel", role: .cancel) { folderName = "" }
        }
        .alert("Files", isPresented: .constant(error != nil)) {
            Button("OK") { error = nil }
        } message: { Text(error ?? "") }
    }

    // MARK: header

    private var header: some View {
        VStack(spacing: 10) {
            HStack {
                Text("Files").font(.title2.bold()).foregroundStyle(Theme.text)
                Spacer()
                Button { newFolder = true } label: {
                    Image(systemName: "folder.badge.plus").foregroundStyle(Theme.accent)
                }
                Button { importing = true } label: {
                    Image(systemName: "square.and.arrow.down").foregroundStyle(Theme.accent)
                }
            }
            HStack(spacing: 8) {
                Button { goUp() } label: {
                    Image(systemName: "chevron.left")
                        .foregroundStyle(atRoot ? Theme.subtle.opacity(0.4) : Theme.accent)
                }
                .disabled(atRoot)
                Text(relPath)
                    .font(.system(size: 13, design: .monospaced))
                    .foregroundStyle(Theme.subtle)
                    .lineLimit(1).truncationMode(.head)
                Spacer()
            }
        }
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 10)
    }

    private var empty: some View {
        VStack(spacing: 8) {
            Spacer()
            Image(systemName: "folder").font(.system(size: 34)).foregroundStyle(Theme.subtle)
            Text("Empty folder").font(.subheadline).foregroundStyle(Theme.subtle)
            Spacer()
        }.frame(maxWidth: .infinity)
    }

    // MARK: rows

    private func row(_ item: FileItem) -> some View {
        Button {
            if item.isDir { dir = item.url; reload() } else { shareURL = item.url }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon(item))
                    .foregroundStyle(item.isDir ? Theme.accent : Theme.text)
                    .frame(width: 22)
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name).foregroundStyle(Theme.text).lineLimit(1)
                    Text(subtitle(item)).font(.caption2).foregroundStyle(Theme.subtle)
                }
                Spacer()
                if item.isDir {
                    Image(systemName: "chevron.right").font(.caption).foregroundStyle(Theme.subtle)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .swipeActions(edge: .trailing) {
            Button(role: .destructive) { remove(item) } label: { Label("Delete", systemImage: "trash") }
            if !item.isDir {
                Button { shareURL = item.url } label: { Label("Share", systemImage: "square.and.arrow.up") }
                    .tint(Theme.accent)
            }
        }
    }

    private func icon(_ i: FileItem) -> String {
        if i.isDir { return "folder.fill" }
        switch i.url.pathExtension.lowercased() {
        case "ipa":              return "app.badge"
        case "p12", "pfx":       return "key.fill"
        case "mobileprovision":  return "doc.badge.gearshape"
        case "png", "jpg", "jpeg": return "photo"
        case "json":             return "curlybraces"
        case "crt", "pem", "cer": return "lock.doc"
        default:                 return "doc"
        }
    }

    private func subtitle(_ i: FileItem) -> String {
        let d = Self.df.string(from: i.modified)
        return i.isDir ? d : "\(Self.bcf.string(fromByteCount: i.size)) · \(d)"
    }

    // MARK: fs ops

    private func reload() {
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        let urls = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: keys,
                                                options: [.skipsHiddenFiles])) ?? []
        let mapped: [FileItem] = urls.map { u in
            let v = try? u.resourceValues(forKeys: Set(keys))
            return FileItem(url: u,
                            isDir: v?.isDirectory ?? false,
                            size: Int64(v?.fileSize ?? 0),
                            modified: v?.contentModificationDate ?? .distantPast)
        }
        items = mapped.sorted {
            if $0.isDir != $1.isDir { return $0.isDir && !$1.isDir }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    private func goUp() {
        guard !atRoot else { return }
        dir = dir.deletingLastPathComponent(); reload()
    }

    private func remove(_ i: FileItem) {
        do { try FileManager.default.removeItem(at: i.url); reload() }
        catch { self.error = error.localizedDescription }
    }

    private func makeFolder() {
        let name = folderName.trimmingCharacters(in: .whitespacesAndNewlines)
        folderName = ""
        guard !name.isEmpty else { return }
        do { try FileManager.default.createDirectory(at: dir.appendingPathComponent(name),
                                                     withIntermediateDirectories: true); reload() }
        catch { self.error = error.localizedDescription }
    }

    private func importFiles(_ urls: [URL]) {
        let fm = FileManager.default
        for src in urls {
            let scoped = src.startAccessingSecurityScopedResource()
            defer { if scoped { src.stopAccessingSecurityScopedResource() } }
            var dest = dir.appendingPathComponent(src.lastPathComponent)
            var n = 1
            while fm.fileExists(atPath: dest.path) {
                let base = src.deletingPathExtension().lastPathComponent
                let ext = src.pathExtension
                let nm = ext.isEmpty ? "\(base) \(n)" : "\(base) \(n).\(ext)"
                dest = dir.appendingPathComponent(nm); n += 1
            }
            do { try fm.copyItem(at: src, to: dest) }
            catch { self.error = error.localizedDescription }
        }
        reload()
    }

    // sheet(item:) needs an Identifiable; wrap the URL.
    private struct SharePayload: Identifiable { let url: URL; var id: String { url.path } }
    private var shareItem: Binding<SharePayload?> {
        Binding(get: { shareURL.map(SharePayload.init) },
                set: { shareURL = $0?.url })
    }

    private static let df: DateFormatter = {
        let f = DateFormatter(); f.dateStyle = .short; f.timeStyle = .short; return f
    }()
    private static let bcf: ByteCountFormatter = {
        let f = ByteCountFormatter(); f.countStyle = .file; return f
    }()
}

/// UIActivityViewController bridge for share/export.
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
