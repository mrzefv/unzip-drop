//
//  UIHelpers.swift
//  mSignLite
//

import SwiftUI
import UniformTypeIdentifiers

/// Rounded app-icon thumbnail from a file URL, with a placeholder fallback.
struct IconThumb: View {
    let url: URL?
    var side: CGFloat = 44

    var body: some View {
        Group {
            if let url, let img = UIImage(contentsOfFile: url.path) {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                RoundedRectangle(cornerRadius: side * 0.22)
                    .fill(Theme.accent.opacity(0.15))
                    .overlay(Image(systemName: "app.dashed").foregroundStyle(Theme.accent))
            }
        }
        .frame(width: side, height: side)
        .clipShape(RoundedRectangle(cornerRadius: side * 0.22))
    }
}

enum FileRead {
    /// Read the bytes of a (possibly security-scoped) picked file.
    static func data(_ url: URL) -> Data? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        return try? Data(contentsOf: url)
    }
}

extension UTType {
    static var ipa: UTType { UTType(filenameExtension: "ipa") ?? .data }
    static var p12: UTType { UTType(filenameExtension: "p12") ?? .data }
    static var pfx: UTType { UTType(filenameExtension: "pfx") ?? .data }
    static var mobileprovision: UTType { UTType(filenameExtension: "mobileprovision") ?? .data }
}
