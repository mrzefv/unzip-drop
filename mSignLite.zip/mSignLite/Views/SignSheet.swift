//
//  SignSheet.swift
//  mSignLite
//

import SwiftUI

final class LogSink: ObservableObject, @unchecked Sendable {
    @Published var lines: [String] = []
    func append(_ s: String) { Task { @MainActor in self.lines.append(s) } }
    func reset() { lines = [] }
}

struct SignSheet: View {
    let app: LocalAppEntry
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var certs = CertificateStore.shared
    @StateObject private var sink = LogSink()

    @State private var name: String
    @State private var bundleID: String
    @State private var version: String
    @State private var signing = false
    @State private var signed: SignedEntry?
    @State private var error: String?

    init(app: LocalAppEntry) {
        self.app = app
        _name = State(initialValue: app.name)
        _bundleID = State(initialValue: app.bundleID)
        _version = State(initialValue: app.version)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.bg.ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 14) {
                        appHeader
                        overrides
                        certRow
                        if !sink.lines.isEmpty { terminal }
                        actionButton
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Sign").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
            .alert("Signing failed", isPresented: .constant(error != nil)) {
                Button("OK") { error = nil }
            } message: { Text(error ?? "") }
        }
        .preferredColorScheme(.dark)
    }

    private var appHeader: some View {
        Card {
            HStack(spacing: 12) {
                IconThumb(url: app.iconURL, side: 52)
                VStack(alignment: .leading, spacing: 3) {
                    Text(app.name).font(.headline).foregroundStyle(Theme.text).lineLimit(1)
                    Text(app.bundleID).font(.caption).foregroundStyle(Theme.subtle).lineLimit(1)
                }
                Spacer()
            }
        }
    }

    private var overrides: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                Text("Overrides").font(.headline).foregroundStyle(Theme.text)
                field("Display name", text: $name)
                field("Bundle identifier", text: $bundleID)
                field("Version", text: $version)
            }
        }
    }

    private var certRow: some View {
        Card {
            HStack(spacing: 10) {
                Image(systemName: certs.active == nil ? "exclamationmark.triangle.fill" : "checkmark.shield.fill")
                    .foregroundStyle(certs.active == nil ? .orange : Theme.accent)
                VStack(alignment: .leading, spacing: 2) {
                    Text(certs.active?.name ?? "No active certificate")
                        .font(.subheadline.weight(.semibold)).foregroundStyle(Theme.text)
                    Text(certs.active == nil ? "Add one in Settings › Certificates." : "Signing identity")
                        .font(.caption).foregroundStyle(Theme.subtle)
                }
                Spacer()
            }
        }
    }

    private var terminal: some View {
        Card {
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(Array(sink.lines.enumerated()), id: \.offset) { i, line in
                            Text(line)
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(line.hasPrefix(">>>") ? Theme.accent : Theme.subtle)
                                .id(i)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(height: 180)
                .onChange(of: sink.lines.count) { newCount in
                    withAnimation { proxy.scrollTo(newCount - 1, anchor: .bottom) }
                }
            }
        }
    }

    @ViewBuilder private var actionButton: some View {
        if let signed {
            Button {
                Task {
                    do { try await OTAInstaller.shared.install(signed) }
                    catch { self.error = error.localizedDescription }
                }
            } label: {
                Label("Install", systemImage: "arrow.down.circle.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 12)
                    .background(Theme.accent).foregroundStyle(Color.black)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
        } else {
            Button(action: sign) {
                HStack {
                    if signing { ProgressView().tint(.black) }
                    Text(signing ? "Signing…" : "Sign")
                }
                .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 12)
                .background(canSign ? Theme.accent : Theme.accent.opacity(0.25))
                .foregroundStyle(canSign ? Color.black : Theme.subtle)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(.plain)
            .disabled(!canSign)
        }
    }

    private var canSign: Bool { !signing && certs.active != nil }

    private func sign() {
        signing = true
        sink.reset()
        let material: CertMaterial
        do { material = try certs.activeMaterial() }
        catch { self.error = error.localizedDescription; signing = false; return }

        let ipa = app.ipaURL
        let n = name, b = bundleID, v = version
        let iconData = app.iconURL.flatMap { try? Data(contentsOf: $0) }
        let sink = self.sink

        Task {
            do {
                let out = try await Signer.signDetached(
                    ipaURL: ipa, material: material,
                    nameOverride: n, bundleIDOverride: b, versionOverride: v,
                    onLog: { line in sink.append(line) }
                )
                let entry = try SignedStore.shared.add(
                    signedTempIPA: out.ipaURL, name: out.name,
                    bundleID: out.bundleID, version: out.version, iconPNG: iconData
                )
                self.signed = entry
            } catch {
                self.error = error.localizedDescription
            }
            self.signing = false
        }
    }

    private func field(_ prompt: String, text: Binding<String>) -> some View {
        TextField(prompt, text: text)
            .autocorrectionDisabled().textInputAutocapitalization(.never)
            .padding(10).background(Theme.bg).foregroundStyle(Theme.text)
            .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}
