//
//  CertificatesView.swift
//  mSignLite
//

import SwiftUI
import UniformTypeIdentifiers

struct CertificatesView: View {
    @ObservedObject var store = CertificateStore.shared

    @State private var showP12 = false
    @State private var showProv = false
    @State private var p12Data: Data?
    @State private var p12Name = ""
    @State private var provData: Data?
    @State private var provName = ""
    @State private var certName = ""
    @State private var password = ""
    @State private var error: String?

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 14) {
                    HStack { Text("Certificates").font(.title2.bold()).foregroundStyle(Theme.text); Spacer() }
                    addCard
                    ForEach(store.certificates) { cert in certRow(cert) }
                }
                .padding(16)
            }
        }
        .fileImporter(isPresented: $showP12, allowedContentTypes: [.p12, .pfx, .data]) { result in
            if case let .success(url) = result, let d = FileRead.data(url) { p12Data = d; p12Name = url.lastPathComponent }
        }
        .fileImporter(isPresented: $showProv, allowedContentTypes: [.mobileprovision, .data]) { result in
            if case let .success(url) = result, let d = FileRead.data(url) { provData = d; provName = url.lastPathComponent }
        }
        .alert("Certificate", isPresented: .constant(error != nil)) {
            Button("OK") { error = nil }
        } message: { Text(error ?? "") }
    }

    private var addCard: some View {
        Card {
            VStack(alignment: .leading, spacing: 10) {
                Text("Add certificate").font(.headline).foregroundStyle(Theme.text)

                pickerRow(title: p12Name.isEmpty ? "Choose .p12" : p12Name,
                          system: "doc.badge.gearshape", set: p12Data != nil) { showP12 = true }
                pickerRow(title: provName.isEmpty ? "Choose .mobileprovision" : provName,
                          system: "doc.text", set: provData != nil) { showProv = true }

                field("Name (optional)", text: $certName, secure: false)
                field("p12 password", text: $password, secure: true)

                Button(action: add) {
                    Text("Add certificate")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity).padding(.vertical, 10)
                        .background(canAdd ? Theme.accent : Theme.accent.opacity(0.25))
                        .foregroundStyle(canAdd ? Color.black : Theme.subtle)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)
                .disabled(!canAdd)
            }
        }
    }

    private var canAdd: Bool { p12Data != nil && provData != nil }

    private func add() {
        guard let p12 = p12Data, let prov = provData else { return }
        do {
            try store.importPair(name: certName, p12: p12, password: password, provision: prov)
            p12Data = nil; provData = nil; p12Name = ""; provName = ""; certName = ""; password = ""
        } catch { self.error = error.localizedDescription }
    }

    private func certRow(_ cert: Certificate) -> some View {
        Card {
            HStack(spacing: 12) {
                Image(systemName: cert.id == store.activeID ? "checkmark.seal.fill" : "seal")
                    .foregroundStyle(cert.id == store.activeID ? Theme.accent : Theme.subtle)
                    .font(.title3)
                VStack(alignment: .leading, spacing: 2) {
                    Text(cert.name).font(.headline).foregroundStyle(Theme.text)
                    Text(cert.id == store.activeID ? "Active" : "Tap to activate")
                        .font(.caption).foregroundStyle(Theme.subtle)
                }
                Spacer()
                Menu {
                    Button("Set active") { store.activeID = cert.id }
                    Button("Delete", role: .destructive) { store.delete(cert) }
                } label: { Image(systemName: "ellipsis.circle").foregroundStyle(Theme.subtle) }
            }
            .contentShape(Rectangle())
            .onTapGesture { store.activeID = cert.id }
        }
    }

    private func pickerRow(title: String, system: String, set: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: system).foregroundStyle(set ? Theme.accent : Theme.subtle)
                Text(title).foregroundStyle(set ? Theme.text : Theme.subtle).lineLimit(1)
                Spacer()
                if set { Image(systemName: "checkmark").foregroundStyle(Theme.accent) }
            }
            .padding(10).background(Theme.bg).clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }

    private func field(_ prompt: String, text: Binding<String>, secure: Bool) -> some View {
        Group {
            if secure { SecureField(prompt, text: text) }
            else { TextField(prompt, text: text).autocorrectionDisabled().textInputAutocapitalization(.never) }
        }
        .padding(10).background(Theme.bg).foregroundStyle(Theme.text)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}
