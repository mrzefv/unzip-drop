//
//  ZsignSigner.swift
//  mSign
//
//  Swift-facing wrapper around the zsign engine (Services/zsign/*).
//  Decoupled from Feather's BundleOptions / AlertKit / Debug / CoreData —
//  pure Foundation, safe to call from anywhere in mSign.
//
//  The underlying C functions come in through mSign-Bridging-Header.h:
//      int  zsign(NSString*app, NSString*prov, NSString*key, NSString*pass,
//                 NSString*bundleid, NSString*displayname, NSString*bundleversion,
//                 bool dontGenerateEmbeddedMobileProvision)
//      bool InjectDyLib(NSString*macho, NSString*dylib, bool weak, bool create)
//      bool ChangeDylibPath(NSString*macho, NSString*old, NSString*new)
//      bool ListDylibs(NSString*macho, NSMutableArray*out)
//      bool UninstallDylibs(NSString*macho, NSArray<NSString*>*list)
//

import Foundation

enum ZsignError: Error, LocalizedError {
    case fileNotFound(String)
    case signingFailed(code: Int32)
    case dylibInjectionFailed(macho: String, dylib: String)
    case appBundleNotFound(inIPA: String)

    var errorDescription: String? {
        switch self {
        case .fileNotFound(let p):           return "zsign: file not found at \(p)"
        case .signingFailed(let c):          return "zsign: signing failed (code \(c))"
        case .dylibInjectionFailed(let m, let d):
                                             return "zsign: failed to inject \(d) into \(m)"
        case .appBundleNotFound(let ipa):    return "zsign: no Payload/*.app inside \(ipa)"
        }
    }
}

/// Stateless entrypoint to the zsign pipeline. All methods are `nonisolated`
/// so they can run off the main actor — `zsign(...)` is blocking C work and
/// should never run on the UI thread. Call from a `Task.detached` or a
/// background `DispatchQueue`.
struct ZsignSigner {

    // MARK: - Core: sign an unpacked .app bundle in place

    /// Signs an extracted `.app` directory in place.
    /// - Parameters:
    ///   - appBundlePath: absolute path to `…/Payload/Foo.app` (or any `.app` dir).
    ///   - provisionPath: absolute path to the `.mobileprovision`.
    ///   - p12Path:       absolute path to the signing `.p12`.
    ///   - p12Password:   password for the `.p12` (pass `""` if none).
    ///   - bundleID/displayName/version: pass non-nil to override Info.plist values.
    ///   - skipEmbeddedProvision: when true, does NOT write embedded.mobileprovision.
    nonisolated static func signAppBundle(
        appBundlePath: String,
        provisionPath: String,
        p12Path: String,
        p12Password: String,
        bundleID: String? = nil,
        displayName: String? = nil,
        version: String? = nil,
        skipEmbeddedProvision: Bool = false
    ) throws {
        let fm = FileManager.default
        for p in [appBundlePath, provisionPath, p12Path] where !fm.fileExists(atPath: p) {
            throw ZsignError.fileNotFound(p)
        }

        let code = zsign(
            appBundlePath,
            provisionPath,
            p12Path,
            p12Password,
            bundleID ?? "",
            displayName ?? "",
            version ?? "",
            skipEmbeddedProvision
        )
        if code != 0 { throw ZsignError.signingFailed(code: code) }
    }

    // MARK: - Convenience: sign a full .ipa

    /// Unpacks an `.ipa`, signs the contained `.app`, repacks to a new `.ipa`.
    /// Bring your own zip handling by passing an `IPAArchiver` — mSign already
    /// has IPA pack/unpack code; conform it to `IPAArchiver` in a few lines
    /// (see INTEGRATION.md). Returns the URL of the signed `.ipa`.
    nonisolated static func signIPA(
        at ipaURL: URL,
        provisionPath: String,
        p12Path: String,
        p12Password: String,
        bundleID: String? = nil,
        displayName: String? = nil,
        version: String? = nil,
        using archiver: IPAArchiver
    ) throws -> URL {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        let appURL = try archiver.unpack(ipa: ipaURL, into: work)
        guard fm.fileExists(atPath: appURL.path) else {
            throw ZsignError.appBundleNotFound(inIPA: ipaURL.lastPathComponent)
        }

        try signAppBundle(
            appBundlePath: appURL.path,
            provisionPath: provisionPath,
            p12Path: p12Path,
            p12Password: p12Password,
            bundleID: bundleID,
            displayName: displayName,
            version: version
        )

        let signed = fm.temporaryDirectory
            .appendingPathComponent(ipaURL.deletingPathExtension().lastPathComponent + "-signed")
            .appendingPathExtension("ipa")
        try? fm.removeItem(at: signed)
        try archiver.pack(payloadRoot: work, to: signed)
        return signed
    }

    // MARK: - Dylib tools (tweak injection)

    nonisolated static func injectDylib(
        intoMachO machoPath: String,
        dylibPath: String,
        weak: Bool = false,
        createIfMissing: Bool = true
    ) throws {
        if !InjectDyLib(machoPath, dylibPath, weak, createIfMissing) {
            throw ZsignError.dylibInjectionFailed(macho: machoPath, dylib: dylibPath)
        }
    }

    nonisolated static func listDylibs(inMachO machoPath: String) -> [String] {
        let out = NSMutableArray()
        _ = ListDylibs(machoPath, out)
        return out.compactMap { $0 as? String }
    }

    @discardableResult
    nonisolated static func removeDylibs(inMachO machoPath: String, _ dylibs: [String]) -> Bool {
        UninstallDylibs(machoPath, dylibs)
    }

    @discardableResult
    nonisolated static func changeDylibPath(inMachO machoPath: String, from old: String, to new: String) -> Bool {
        ChangeDylibPath(machoPath, old, new)
    }
}

/// Plug mSign's existing IPA zip handling into zsign's IPA convenience.
protocol IPAArchiver {
    /// Extract `ipa` under `dir` and return the URL of `dir/Payload/<App>.app`.
    func unpack(ipa: URL, into dir: URL) throws -> URL
    /// Zip everything under `payloadRoot` (which contains `Payload/`) into `ipa`.
    func pack(payloadRoot: URL, to ipa: URL) throws
}
