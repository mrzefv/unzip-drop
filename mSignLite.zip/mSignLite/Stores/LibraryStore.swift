//
//  LibraryStore.swift
//  mSignLite
//
//  The unsigned-IPA library and the signed-IPA shelf. Both are just a
//  folder of files plus a JSON index in Documents.
//

import Foundation
import UIKit

@MainActor
final class LibraryStore: ObservableObject {
    static let shared = LibraryStore()

    @Published private(set) var apps: [LocalAppEntry] = []
    private let indexURL = AppPaths.dir("library").appendingPathComponent("index.json")

    private init() { load() }

    /// Import an .ipa from a URL (file picker gives a security-scoped URL).
    @discardableResult
    func importIPA(from src: URL) async throws -> LocalAppEntry {
        let scoped = src.startAccessingSecurityScopedResource()
        defer { if scoped { src.stopAccessingSecurityScopedResource() } }

        let id = UUID().uuidString
        let meta = try IPAMeta.read(src)

        let ipaRel = "library/\(id).ipa"
        try FileManager.default.copyItem(at: src, to: AppPaths.documents.appendingPathComponent(ipaRel))

        var iconRel: String?
        if let icon = meta.iconPNG {
            iconRel = "library/\(id).png"
            try? icon.write(to: AppPaths.documents.appendingPathComponent(iconRel!))
        }

        let entry = LocalAppEntry(
            id: id,
            name: meta.name,
            bundleID: meta.bundleID,
            version: meta.version,
            ipaRelPath: ipaRel,
            iconRelPath: iconRel,
            importedAt: Date()
        )
        apps.insert(entry, at: 0)
        save()
        return entry
    }

    func delete(_ app: LocalAppEntry) {
        try? FileManager.default.removeItem(at: app.ipaURL)
        if let i = app.iconURL { try? FileManager.default.removeItem(at: i) }
        apps.removeAll { $0.id == app.id }
        save()
    }

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let list = try? JSONDecoder().decode([LocalAppEntry].self, from: data) else { return }
        apps = list
    }
    private func save() { try? JSONEncoder().encode(apps).write(to: indexURL) }
}

@MainActor
final class SignedStore: ObservableObject {
    static let shared = SignedStore()

    @Published private(set) var apps: [SignedEntry] = []
    private let indexURL = AppPaths.dir("signed").appendingPathComponent("index.json")

    private init() { load() }

    /// Move a freshly-signed temp .ipa into permanent storage.
    @discardableResult
    func add(signedTempIPA: URL, name: String, bundleID: String, version: String,
             iconPNG: Data?) throws -> SignedEntry {
        let id = UUID().uuidString
        let ipaRel = "signed/\(id).ipa"
        let dst = AppPaths.documents.appendingPathComponent(ipaRel)
        try? FileManager.default.removeItem(at: dst)
        try FileManager.default.moveItem(at: signedTempIPA, to: dst)

        var iconRel: String?
        if let icon = iconPNG {
            iconRel = "signed/\(id).png"
            try? icon.write(to: AppPaths.documents.appendingPathComponent(iconRel!))
        }

        let entry = SignedEntry(id: id, name: name, bundleID: bundleID, version: version,
                                ipaRelPath: ipaRel, iconRelPath: iconRel, signedAt: Date())
        apps.insert(entry, at: 0)
        save()
        return entry
    }

    func delete(_ app: SignedEntry) {
        try? FileManager.default.removeItem(at: app.ipaURL)
        if let i = app.iconURL { try? FileManager.default.removeItem(at: i) }
        apps.removeAll { $0.id == app.id }
        save()
    }

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let list = try? JSONDecoder().decode([SignedEntry].self, from: data) else { return }
        apps = list
    }
    private func save() { try? JSONEncoder().encode(apps).write(to: indexURL) }
}
