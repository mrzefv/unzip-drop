//
//  SignedView.swift
//  mSignLite
//

import SwiftUI

struct SignedView: View {
    @ObservedObject var store = SignedStore.shared
    @State private var installing: String?
    @State private var error: String?

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            ScrollView {
                LazyVStack(spacing: 10) {
                    HStack {
                        Text("Signed").font(.title2.bold()).foregroundStyle(Theme.text)
                        Spacer()
                    }
                    if store.apps.isEmpty {
                        empty
                    } else {
                        ForEach(store.apps) { app in
                            row(app)
                                .contextMenu {
                                    Button(role: .destructive) { store.delete(app) } label: {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                        }
                    }
                }
                .padding(16)
            }
        }
        .alert("Install failed", isPresented: .constant(error != nil)) {
            Button("OK") { error = nil }
        } message: { Text(error ?? "") }
    }

    private func row(_ app: SignedEntry) -> some View {
        Card {
            HStack(spacing: 12) {
                IconThumb(url: app.iconURL)
                VStack(alignment: .leading, spacing: 3) {
                    Text(app.name).font(.headline).foregroundStyle(Theme.text).lineLimit(1)
                    Text(app.bundleID).font(.caption).foregroundStyle(Theme.subtle).lineLimit(1)
                }
                Spacer()
                Button {
                    install(app)
                } label: {
                    if installing == app.id {
                        ProgressView().tint(Theme.accent)
                    } else {
                        Label("Install", systemImage: "arrow.down.circle.fill")
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 12).padding(.vertical, 8)
                            .background(Theme.accent.opacity(0.16))
                            .foregroundStyle(Theme.accent)
                            .clipShape(Capsule())
                    }
                }
                .buttonStyle(.plain)
                .disabled(installing != nil)
            }
        }
    }

    private func install(_ app: SignedEntry) {
        installing = app.id
        Task {
            do { try await OTAInstaller.shared.install(app) }
            catch { self.error = error.localizedDescription }
            installing = nil
        }
    }

    private var empty: some View {
        VStack(spacing: 10) {
            Image(systemName: "checkmark.seal").font(.largeTitle).foregroundStyle(Theme.subtle)
            Text("Nothing signed yet").foregroundStyle(Theme.text)
            Text("Sign an app from the Library tab.").font(.footnote).foregroundStyle(Theme.subtle)
        }
        .frame(maxWidth: .infinity).padding(.top, 60)
    }
}
