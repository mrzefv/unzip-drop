//
//  TopBar.swift
//  mSignLite
//

import SwiftUI

struct TopBar: View {
    @ObservedObject var certs = CertificateStore.shared

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "paintbrush.pointed.fill")
                .foregroundStyle(Theme.accent)
                .font(.system(size: 18, weight: .semibold))

            (Text("mSIGN ").fontWeight(.bold) + Text("LITE").fontWeight(.regular).foregroundColor(Theme.subtle))
                .font(.system(size: 18))
                .foregroundStyle(Theme.text)

            Spacer()

            HStack(spacing: 6) {
                Circle()
                    .fill(certs.active == nil ? Color.orange : Theme.accent)
                    .frame(width: 8, height: 8)
                Text(certs.active?.name ?? "No cert")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(Theme.subtle)
                    .lineLimit(1)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Theme.bg)
        .overlay(Rectangle().fill(Theme.accent.opacity(0.25)).frame(height: 1), alignment: .bottom)
    }
}
