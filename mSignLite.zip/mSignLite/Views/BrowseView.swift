//
//  BrowseView.swift
//  mSignLite
//
//  An in-app browser. Point it at a repo, tap an .ipa link, and the
//  download lands straight in your Library — no Files round-trip.
//  Defaults to mrzefv.com.
//

import SwiftUI
import WebKit

private let kHomeKey = "msignlite_browse_home"

enum BrowseConfig {
    static var home: String {
        UserDefaults.standard.string(forKey: kHomeKey) ?? "https://mrzefv.com"
    }
    static func setHome(_ s: String) {
        let v = s.trimmingCharacters(in: .whitespaces)
        UserDefaults.standard.set(v.isEmpty ? "https://mrzefv.com" : v, forKey: kHomeKey)
    }
}

@MainActor
final class WebModel: ObservableObject {
    @Published var address = BrowseConfig.home
    @Published var canBack = false
    @Published var canForward = false
    @Published var progress: Double = 0
    @Published var loading = false
    @Published var status: String?

    weak var web: WKWebView?

    func load(_ raw: String) {
        var s = raw.trimmingCharacters(in: .whitespaces)
        guard !s.isEmpty else { return }
        if !s.contains("://") {
            // domain-ish → https, otherwise Google search
            if s.contains(" ") || !s.contains(".") {
                s = "https://www.google.com/search?q=" +
                    (s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s)
            } else {
                s = "https://" + s
            }
        }
        guard let url = URL(string: s) else { return }
        web?.load(URLRequest(url: url))
    }

    func goHome() { address = BrowseConfig.home; load(address) }
    func flash(_ s: String) {
        status = s
        Task { try? await Task.sleep(nanoseconds: 2_500_000_000); if status == s { status = nil } }
    }
}

struct BrowseView: View {
    @StateObject private var model = WebModel()
    @FocusState private var barFocused: Bool

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            VStack(spacing: 0) {
                bar
                ZStack(alignment: .top) {
                    WebView(model: model)
                    if model.loading {
                        ProgressView(value: model.progress)
                            .tint(Theme.accent)
                            .background(Theme.bg)
                    }
                }
            }
            if let s = model.status {
                VStack {
                    Spacer()
                    Text(s)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(Theme.text)
                        .padding(.horizontal, 14).padding(.vertical, 10)
                        .background(Theme.card)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.accent.opacity(0.5), lineWidth: 1))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .padding(.bottom, 18)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .animation(.easeInOut, value: model.status)
            }
        }
    }

    private var bar: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Browse").font(.title2.bold()).foregroundStyle(Theme.text)
                Spacer()
                Button { model.goHome() } label: {
                    Image(systemName: "house.fill").foregroundStyle(Theme.accent)
                }
            }
            HStack(spacing: 10) {
                Button { model.web?.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!model.canBack).foregroundStyle(model.canBack ? Theme.accent : Theme.subtle.opacity(0.4))
                Button { model.web?.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!model.canForward).foregroundStyle(model.canForward ? Theme.accent : Theme.subtle.opacity(0.4))

                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").font(.caption).foregroundStyle(Theme.subtle)
                    TextField("Search or enter address", text: $model.address)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .keyboardType(.webSearch).submitLabel(.go)
                        .foregroundStyle(Theme.text)
                        .focused($barFocused)
                        .onSubmit { model.load(model.address); barFocused = false }
                }
                .padding(.horizontal, 10).padding(.vertical, 8)
                .background(Theme.card)
                .clipShape(RoundedRectangle(cornerRadius: 10))

                Button { model.loading ? model.web?.stopLoading() : model.web?.reload() } label: {
                    Image(systemName: model.loading ? "xmark" : "arrow.clockwise").foregroundStyle(Theme.accent)
                }
            }
        }
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 10)
        .background(Theme.bg)
        .overlay(Rectangle().fill(Theme.stroke).frame(height: 1), alignment: .bottom)
    }
}

// MARK: - WKWebView bridge

struct WebView: UIViewRepresentable {
    @ObservedObject var model: WebModel

    func makeCoordinator() -> Coordinator { Coordinator(model: model) }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.defaultWebpagePreferences.allowsContentJavaScript = true
        let web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = context.coordinator
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false
        web.backgroundColor = UIColor(Theme.bg)
        web.scrollView.backgroundColor = UIColor(Theme.bg)
        context.coordinator.attach(web)
        model.web = web
        if let url = URL(string: model.address) { web.load(URLRequest(url: url)) }
        return web
    }

    func updateUIView(_ web: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKDownloadDelegate {
        let model: WebModel
        private var obs: [NSKeyValueObservation] = []

        init(model: WebModel) { self.model = model }

        func attach(_ web: WKWebView) {
            obs = [
                web.observe(\.estimatedProgress, options: [.new]) { [weak self] w, _ in
                    Task { @MainActor in self?.model.progress = w.estimatedProgress }
                },
                web.observe(\.isLoading, options: [.new]) { [weak self] w, _ in
                    Task { @MainActor in self?.model.loading = w.isLoading }
                },
                web.observe(\.url, options: [.new]) { [weak self] w, _ in
                    Task { @MainActor in if let u = w.url?.absoluteString { self?.model.address = u } }
                },
                web.observe(\.canGoBack, options: [.new]) { [weak self] w, _ in
                    Task { @MainActor in self?.model.canBack = w.canGoBack }
                },
                web.observe(\.canGoForward, options: [.new]) { [weak self] w, _ in
                    Task { @MainActor in self?.model.canForward = w.canGoForward }
                },
            ]
        }

        // Turn .ipa link taps into downloads.
        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.request.url?.pathExtension.lowercased() == "ipa" {
                decisionHandler(.download)
            } else {
                decisionHandler(.allow)
            }
        }

        // Anything the browser can't render (or an .ipa) → download.
        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationResponse: WKNavigationResponse,
                     decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            let isIPA = navigationResponse.response.url?.pathExtension.lowercased() == "ipa"
            if isIPA || !navigationResponse.canShowMIMEType {
                decisionHandler(.download)
            } else {
                decisionHandler(.allow)
            }
        }

        func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
            download.delegate = self
        }
        func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
            download.delegate = self
        }

        // MARK: WKDownloadDelegate
        func download(_ download: WKDownload,
                      decideDestinationUsing response: URLResponse,
                      suggestedFilename: String,
                      completionHandler: @escaping (URL?) -> Void) {
            let name = suggestedFilename.isEmpty ? "download.ipa" : suggestedFilename
            let tmp = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            try? FileManager.default.createDirectory(at: tmp, withIntermediateDirectories: true)
            let dest = tmp.appendingPathComponent(name)
            Task { @MainActor in self.model.flash("Downloading \(name)…") }
            completionHandler(dest)
        }

        func downloadDidFinish(_ download: WKDownload) {
            guard let dest = download.progress.fileURL ?? lastDest(download) else { return }
            Task { @MainActor in
                if dest.pathExtension.lowercased() == "ipa" {
                    do {
                        let entry = try await LibraryStore.shared.importIPA(from: dest)
                        model.flash("Added “\(entry.name)” to Library")
                    } catch {
                        model.flash("Import failed: \(error.localizedDescription)")
                    }
                } else {
                    model.flash("Downloaded \(dest.lastPathComponent)")
                }
                try? FileManager.default.removeItem(at: dest.deletingLastPathComponent())
            }
        }

        func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
            Task { @MainActor in self.model.flash("Download failed: \(error.localizedDescription)") }
        }

        // progress.fileURL is the reliable destination on recent iOS; keep a tiny fallback.
        private func lastDest(_ d: WKDownload) -> URL? { d.progress.fileURL }
    }
}
