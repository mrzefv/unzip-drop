//
//  LibraryView.swift
//  mSignLite
//

import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    @ObservedObject var store = LibraryStore.shared
    @State private var importing = false
    @State private var signTarget: LocalAppEntry?
    @State private var error: String?

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            ScrollView {
                LazyVStack(spacing: 10) {
                    header
                    if store.apps.isEmpty {
                        empty
                    } else {
                        ForEach(store.apps) { app in
                            Button { signTarget = app } label: { row(app) }
                                .buttonStyle(.plain)
                                .contextMenu {
                                    Button(role: .destructive) { store.delete(app) } label: {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                        }
                    }
                }
                .padding(16)
            }
        }
        .fileImporter(isPresented: $importing,
                      allowedContentTypes: [.ipa, .zip, .data],
                      allowsMultipleSelection: false) { result in
            if case let .success(urls) = result, let url = urls.first {
                Task {
                    do { try await store.importIPA(from: url) }
                    catch { self.error = error.localizedDescription }
                }
            }
        }
        .alert("Import failed", isPresented: .constant(error != nil)) {
            Button("OK") { error = nil }
        } message: { Text(error ?? "") }
        .sheet(item: $signTarget) { app in SignSheet(app: app) }
    }

    private var header: some View {
        HStack {
            Text("Library").font(.title2.bold()).foregroundStyle(Theme.text)
            Spacer()
            Button { importing = true } label: {
                Label("Import IPA", systemImage: "plus")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(Theme.accent.opacity(0.16))
                    .foregroundStyle(Theme.accent)
                    .clipShape(Capsule())
            }
        }
    }

    private func row(_ app: LocalAppEntry) -> some View {
        Card {
            HStack(spacing: 12) {
                IconThumb(url: app.iconURL)
                VStack(alignment: .leading, spacing: 3) {
                    Text(app.name).font(.headline).foregroundStyle(Theme.text).lineLimit(1)
                    Text(app.bundleID).font(.caption).foregroundStyle(Theme.subtle).lineLimit(1)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 3) {
                    Text("v\(app.version)").font(.caption.weight(.medium)).foregroundStyle(Theme.subtle)
                    Image(systemName: "signature").foregroundStyle(Theme.accent)
                }
            }
        }
    }

    private var empty: some View {
        VStack(spacing: 10) {
            Image(systemName: "tray.and.arrow.down").font(.largeTitle).foregroundStyle(Theme.subtle)
            Text("No apps yet").foregroundStyle(Theme.text)
            Text("Import an .ipa to sign it on-device.").font(.footnote).foregroundStyle(Theme.subtle)
        }
        .frame(maxWidth: .infinity).padding(.top, 60)
    }
}
