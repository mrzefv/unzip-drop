//
//  IPAMeta.swift
//  mSignLite
//
//  Pulls display name / bundle id / version and a best-effort primary
//  icon out of an .ipa by unzipping it to a temp dir and reading
//  Payload/*.app/Info.plist. Uses only FileManager+ZIPFoundation, which
//  is stable across ZIPFoundation versions.
//

import Foundation

struct IPAMeta: Sendable {
    var name: String
    var bundleID: String
    var version: String
    var iconPNG: Data?

    static func read(_ ipa: URL) throws -> IPAMeta {
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appendingPathComponent("meta-\(UUID().uuidString)", isDirectory: true)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: work) }

        try fm.unzipItem(at: ipa, to: work)

        let payload = work.appendingPathComponent("Payload", isDirectory: true)
        guard let app = try? fm.contentsOfDirectory(at: payload, includingPropertiesForKeys: nil)
            .first(where: { $0.pathExtension == "app" }) else {
            // Not a normal IPA layout — fall back to the filename.
            let base = ipa.deletingPathExtension().lastPathComponent
            return IPAMeta(name: base, bundleID: "unknown.bundle.id", version: "1.0", iconPNG: nil)
        }

        let info = NSDictionary(contentsOf: app.appendingPathComponent("Info.plist"))
        let name = (info?["CFBundleDisplayName"] as? String)
            ?? (info?["CFBundleName"] as? String)
            ?? app.deletingPathExtension().lastPathComponent
        let bundleID = (info?["CFBundleIdentifier"] as? String) ?? "unknown.bundle.id"
        let version  = (info?["CFBundleShortVersionString"] as? String)
            ?? (info?["CFBundleVersion"] as? String) ?? "1.0"

        let icon = primaryIcon(in: app, info: info)
        return IPAMeta(name: name, bundleID: bundleID, version: version, iconPNG: icon)
    }

    /// Best effort: resolve the primary icon file name from Info.plist, else
    /// grab the largest AppIcon*.png at the app root.
    private static func primaryIcon(in app: URL, info: NSDictionary?) -> Data? {
        let fm = FileManager.default
        var candidateNames: [String] = []

        if let icons = info?["CFBundleIcons"] as? [String: Any],
           let primary = icons["CFBundlePrimaryIcon"] as? [String: Any],
           let files = primary["CFBundleIconFiles"] as? [String] {
            candidateNames = files.reversed()   // last is usually the largest
        }

        let all = (try? fm.contentsOfDirectory(at: app, includingPropertiesForKeys: [.fileSizeKey]))?
            .filter { $0.pathExtension.lowercased() == "png" } ?? []

        // Prefer a file matching a declared icon base name.
        for base in candidateNames {
            if let hit = all.first(where: { $0.lastPathComponent.hasPrefix(base) }),
               let d = try? Data(contentsOf: hit) { return d }
        }
        // Otherwise the biggest PNG that looks like an app icon.
        let iconish = all.filter { $0.lastPathComponent.localizedCaseInsensitiveContains("AppIcon")
            || $0.lastPathComponent.localizedCaseInsensitiveContains("Icon") }
        let pool = iconish.isEmpty ? all : iconish
        let largest = pool.max { (a, b) in
            let sa = (try? a.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            let sb = (try? b.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            return sa < sb
        }
        return largest.flatMap { try? Data(contentsOf: $0) }
    }
}
