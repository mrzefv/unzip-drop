//
//  CertificateStore.swift
//  mSignLite
//
//  Imports a signing pair (.p12 + .mobileprovision), validates the .p12
//  password with SecPKCS12Import, and persists everything under
//  Documents/certs. Passwords go to the Keychain. One cert is "active"
//  at a time and is what the signer uses.
//

import Foundation
import Security

@MainActor
final class CertificateStore: ObservableObject {
    static let shared = CertificateStore()

    @Published private(set) var certificates: [Certificate] = []
    @Published var activeID: String? {
        didSet { UserDefaults.standard.set(activeID, forKey: Self.activeKey) }
    }

    private static let activeKey = "msignlite_active_cert"
    private let indexURL = AppPaths.dir("certs").appendingPathComponent("index.json")

    private init() {
        load()
        activeID = UserDefaults.standard.string(forKey: Self.activeKey)
        if activeID == nil { activeID = certificates.first?.id }
    }

    enum CertError: LocalizedError {
        case badPassword
        case importFailed
        case noActive
        var errorDescription: String? {
            switch self {
            case .badPassword:  return "Wrong .p12 password (or the file isn't a valid PKCS#12)."
            case .importFailed: return "Could not read the certificate files."
            case .noActive:     return "No active certificate. Import one first."
            }
        }
    }

    // MARK: - Import

    /// Validates the password against the .p12 and, on success, stores the pair.
    @discardableResult
    func importPair(name: String, p12: Data, password: String, provision: Data,
                    makeActive: Bool = true) throws -> Certificate {
        guard Self.p12IsValid(p12, password: password) else { throw CertError.badPassword }

        let id = UUID().uuidString
        let p12Rel  = "certs/\(id).p12"
        let provRel = "certs/\(id).mobileprovision"
        do {
            try p12.write(to: AppPaths.documents.appendingPathComponent(p12Rel))
            try provision.write(to: AppPaths.documents.appendingPathComponent(provRel))
        } catch { throw CertError.importFailed }

        Keychain.set(password, for: id)
        let cert = Certificate(id: id, name: name.isEmpty ? "Certificate" : name,
                               p12RelPath: p12Rel, provisionRelPath: provRel, addedAt: Date())
        certificates.append(cert)
        save()
        if makeActive || activeID == nil { activeID = id }
        return cert
    }

    func delete(_ cert: Certificate) {
        try? FileManager.default.removeItem(at: cert.p12URL)
        try? FileManager.default.removeItem(at: cert.provisionURL)
        Keychain.delete(cert.id)
        certificates.removeAll { $0.id == cert.id }
        if activeID == cert.id { activeID = certificates.first?.id }
        save()
    }

    // MARK: - Material for signing

    var active: Certificate? { certificates.first { $0.id == activeID } }

    func activeMaterial() throws -> CertMaterial {
        guard let c = active else { throw CertError.noActive }
        guard let p12 = try? Data(contentsOf: c.p12URL),
              let mp  = try? Data(contentsOf: c.provisionURL) else { throw CertError.importFailed }
        return CertMaterial(p12: p12, provision: mp,
                            password: Keychain.get(c.id) ?? "", name: c.name)
    }

    // MARK: - Validation

    static func p12IsValid(_ data: Data, password: String) -> Bool {
        let opts = [kSecImportExportPassphrase as String: password] as CFDictionary
        var items: CFArray?
        let status = SecPKCS12Import(data as CFData, opts, &items)
        return status == errSecSuccess
    }

    // MARK: - Persistence

    private func load() {
        guard let data = try? Data(contentsOf: indexURL),
              let list = try? JSONDecoder().decode([Certificate].self, from: data) else { return }
        certificates = list
    }
    private func save() {
        try? JSONEncoder().encode(certificates).write(to: indexURL)
    }
}
