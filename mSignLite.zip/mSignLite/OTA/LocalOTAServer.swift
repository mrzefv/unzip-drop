//
//  LocalOTAServer.swift
//  mSignLite
//
//  On-device OTA install with NO server dependency (no Vapor / SwiftNIO).
//  A tiny HTTPS server on Network.framework's NWListener serves an
//  itms-services manifest + the signed IPA, secured by the bundled
//  wildcard cert.
//
//  The self-reliant-domain trick: the install host (default mr.zefv.dev)
//  resolves to 127.0.0.1 and is covered by the bundled *.zefv.dev
//  Let's Encrypt cert (Resources/server.p12). iOS trusts the cert,
//  connects to loopback, and installs — no network, no backend.
//
//  Swap in your own domain by dropping a matching cert pair in Resources
//  and setting ServerConfig.installHost.
//

import Foundation
import Network
import Security

enum ServerConfig {
    /// Must resolve to 127.0.0.1 and be covered by the bundled cert.
    static var installHost: String {
        UserDefaults.standard.string(forKey: "msignlite_install_host") ?? "mr.zefv.dev"
    }
    static func setInstallHost(_ h: String) {
        UserDefaults.standard.set(h, forKey: "msignlite_install_host")
    }
    /// Bundled PKCS#12 (cert + key) resource name: Resources/server.p12
    static let p12Resource = "server"
}

/// Everything the request handlers need — all Sendable, captured by value
/// so the network queue never touches the server object.
private struct Routes: Sendable {
    let ident: String
    let manifest: Data
    let ipaURL: URL
    let icon57: Data
    let icon512: Data
}

final class LocalOTAServer: @unchecked Sendable {
    let port: UInt16
    let ident = UUID().uuidString
    private let listener: NWListener
    private static let queue = DispatchQueue(label: "msignlite.ota", qos: .userInitiated)

    enum OTAServerError: LocalizedError {
        case noIdentity
        var errorDescription: String? {
            "Install cert (Resources/server.p12) is missing or unreadable."
        }
    }

    init(ipaURL: URL, bundleID: String, name: String, version: String,
         icon57: Data, icon512: Data) throws {
        let p = UInt16.random(in: 4000...8000)
        self.port = p

        guard let tls = Self.tlsOptions() else { throw OTAServerError.noIdentity }
        let params = NWParameters(tls: tls)
        params.allowLocalEndpointReuse = true
        params.includePeerToPeer = false

        let host = ServerConfig.installHost
        func url(_ suffix: String) -> String { "https://\(host):\(p)/\(ident)\(suffix)" }
        let manifest: [String: Any] = [
            "items": [[
                "assets": [
                    ["kind": "software-package", "url": url(".ipa")],
                    ["kind": "display-image",    "url": url("-57.png")],
                    ["kind": "full-size-image",  "url": url("-512.png")],
                ],
                "metadata": [
                    "bundle-identifier": bundleID,
                    "bundle-version":    version,
                    "kind":  "software",
                    "title": name,
                ],
            ]],
        ]
        let manifestData = (try? PropertyListSerialization.data(
            fromPropertyList: manifest, format: .xml, options: 0)) ?? Data()

        let routes = Routes(ident: ident, manifest: manifestData,
                            ipaURL: ipaURL, icon57: icon57, icon512: icon512)

        self.listener = try NWListener(using: params, on: NWEndpoint.Port(rawValue: p)!)
        listener.newConnectionHandler = { conn in
            conn.start(queue: Self.queue)
            Self.receive(conn, buffer: Data(), routes: routes)
        }
    }

    func start() { listener.start(queue: Self.queue) }
    func stop() { listener.cancel() }

    var itmsURL: URL {
        var c = URLComponents()
        c.scheme = "itms-services"
        c.path = "/"
        c.queryItems = [
            .init(name: "action", value: "download-manifest"),
            .init(name: "url", value: "https://\(ServerConfig.installHost):\(port)/\(ident).plist"),
        ]
        return c.url!
    }

    // MARK: - TLS identity (bundled p12 → SecIdentity)

    private static func tlsOptions() -> NWProtocolTLS.Options? {
        guard let identity = loadIdentity(), let sid = sec_identity_create(identity) else { return nil }
        let opts = NWProtocolTLS.Options()
        sec_protocol_options_set_local_identity(opts.securityProtocolOptions, sid)
        sec_protocol_options_set_min_tls_protocol_version(opts.securityProtocolOptions, .TLSv12)
        return opts
    }

    private static func loadIdentity() -> SecIdentity? {
        guard let url = Bundle.main.url(forResource: ServerConfig.p12Resource, withExtension: "p12"),
              let data = try? Data(contentsOf: url) else { return nil }
        let opts = [kSecImportExportPassphrase as String: ""] as CFDictionary
        var items: CFArray?
        guard SecPKCS12Import(data as CFData, opts, &items) == errSecSuccess,
              let arr = items as? [[String: Any]], let first = arr.first,
              let idObj = first[kSecImportItemIdentity as String] else { return nil }
        return (idObj as! SecIdentity)
    }

    // MARK: - Minimal HTTP/1.1

    private static func receive(_ conn: NWConnection, buffer: Data, routes: Routes) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { data, _, isComplete, error in
            var acc = buffer
            if let data { acc.append(data) }

            if let headerEnd = acc.range(of: Data("\r\n\r\n".utf8)) {
                let header = String(decoding: acc[acc.startIndex..<headerEnd.lowerBound], as: UTF8.self)
                dispatch(conn, header: header, routes: routes)
                return
            }
            if error == nil, !isComplete, acc.count < 1 << 20 {
                receive(conn, buffer: acc, routes: routes)
            } else {
                conn.cancel()
            }
        }
    }

    private static func dispatch(_ conn: NWConnection, header: String, routes: Routes) {
        let lines = header.split(separator: "\r\n", omittingEmptySubsequences: false)
        guard let requestLine = lines.first else { conn.cancel(); return }
        let parts = requestLine.split(separator: " ")
        guard parts.count >= 2 else { conn.cancel(); return }
        let path = String(parts[1])

        let rangeHeader = lines.first { $0.lowercased().hasPrefix("range:") }.map(String.init)

        switch path {
        case "/ping":
            send(conn, status: "200 OK", type: "text/plain", body: Data("pong".utf8))
        case "/\(routes.ident).plist":
            send(conn, status: "200 OK", type: "text/xml", body: routes.manifest)
        case "/\(routes.ident)-57.png":
            send(conn, status: "200 OK", type: "image/png", body: routes.icon57)
        case "/\(routes.ident)-512.png":
            send(conn, status: "200 OK", type: "image/png", body: routes.icon512)
        case "/\(routes.ident).ipa":
            streamFile(conn, url: routes.ipaURL, rangeHeader: rangeHeader)
        default:
            send(conn, status: "404 Not Found", type: "text/plain", body: Data("not found".utf8))
        }
    }

    private static func send(_ conn: NWConnection, status: String, type: String, body: Data) {
        var head = "HTTP/1.1 \(status)\r\n"
        head += "Content-Type: \(type)\r\n"
        head += "Content-Length: \(body.count)\r\n"
        head += "Connection: close\r\n\r\n"
        var packet = Data(head.utf8); packet.append(body)
        conn.send(content: packet, isComplete: true, completion: .contentProcessed { _ in conn.cancel() })
    }

    private static func streamFile(_ conn: NWConnection, url: URL, rangeHeader: String?) {
        let fm = FileManager.default
        let attrs = try? fm.attributesOfItem(atPath: url.path)
        let total = (attrs?[.size] as? Int) ?? 0
        guard total > 0, let fh = try? FileHandle(forReadingFrom: url) else {
            send(conn, status: "404 Not Found", type: "text/plain", body: Data("no ipa".utf8)); return
        }

        var start = 0, end = total - 1, status = "200 OK"
        if let r = rangeHeader,
           let eq = r.firstIndex(of: "="),
           case let spec = r[r.index(after: eq)...].trimmingCharacters(in: .whitespaces),
           let dash = spec.firstIndex(of: "-") {
            let lo = Int(spec[spec.startIndex..<dash]) ?? 0
            let hiStr = spec[spec.index(after: dash)...]
            let hi = Int(hiStr) ?? (total - 1)
            start = max(0, lo); end = min(total - 1, hi); status = "206 Partial Content"
        }
        let length = max(0, end - start + 1)

        var head = "HTTP/1.1 \(status)\r\n"
        head += "Content-Type: application/octet-stream\r\n"
        head += "Accept-Ranges: bytes\r\n"
        if status.hasPrefix("206") { head += "Content-Range: bytes \(start)-\(end)/\(total)\r\n" }
        head += "Content-Length: \(length)\r\n"
        head += "Connection: close\r\n\r\n"

        try? fh.seek(toOffset: UInt64(start))
        var remaining = length
        let chunkSize = 1 << 20   // 1 MB

        func pump() {
            if remaining <= 0 {
                conn.send(content: nil, isComplete: true, completion: .contentProcessed { _ in
                    try? fh.close(); conn.cancel()
                })
                return
            }
            let want = min(chunkSize, remaining)
            let chunk = (try? fh.read(upToCount: want)) ?? Data()
            if chunk.isEmpty {
                conn.send(content: nil, isComplete: true, completion: .contentProcessed { _ in
                    try? fh.close(); conn.cancel()
                })
                return
            }
            remaining -= chunk.count
            let last = remaining <= 0
            conn.send(content: chunk, isComplete: last, completion: .contentProcessed { _ in
                if last { try? fh.close(); conn.cancel() } else { pump() }
            })
        }

        conn.send(content: Data(head.utf8), isComplete: false, completion: .contentProcessed { _ in pump() })
    }
}
